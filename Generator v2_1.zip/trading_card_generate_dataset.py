"""
Trading Card Print Shop — Synthetic Dataset Generator (V2.1 - Customer & High-Volume Update)
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import sys
import os
import time

# ── 1. The "Search & Capture" Excel Import ───────────────────────────────────
script_dir = os.path.dirname(os.path.abspath(__file__))
excel_path = os.path.join(script_dir, "simulation_inputs.xlsx")

# Self-Healing Check
if not os.path.exists(excel_path):
    print(f"⚠️ 'simulation_inputs.xlsx' not found. Attempting auto-generate...")
    try:
        import create_excel_dashboard
        create_excel_dashboard.create_control_panel()
        time.sleep(0.5) 
    except Exception as e:
        print(f"❌ Failed to auto-generate Excel file: {e}")
        sys.exit(1)

try:
    df_front = pd.read_excel(excel_path, sheet_name="Main Control Panel", header=None)
    df_back  = pd.read_excel(excel_path, sheet_name="Backend Engine", header=None)
    df_all   = pd.concat([df_front, df_back])

    target_variables = [
        "SCENARIO_NAME", "MAKEREADY_ATTEMPTS", "SHEETS_PER_ATTEMPT", "DEFECT_WINDOW_SHEETS",
        "MIX_121_PLAIN", "MIX_121_HOLO", "MIX_100_PLAIN", "MIX_100_HOLO",
        "SHIFT_MIX_RED_DAY", "SHIFT_MIX_RED_NIGHT", "SHIFT_MIX_BLACK_DAY", "SHIFT_MIX_BLACK_NIGHT",
        "NIGHT_WASTE_FACTOR", "NIGHT_QUALITY_FACTOR", "FOIL_WASTE_FACTOR", "FOIL_MAKEREADY_FACTOR", "FOIL_SPEED_PENALTY",
        "SHARE_SF1", "SHARE_SF2", "SHARE_SF3", "SHARE_SF4", "SHARE_PF1", "SHARE_PF2",
        "AGE_FACTOR_SF3", "AGE_FACTOR_PF2", "SHEETFED_RATE_HR", "PERFECTING_RATE_HR",
        "STOCK_COST_WHITE", "STOCK_COST_FOIL", "INK_COST_PER_LB",
        "NUM_JOBS", "DATE_RANGE_DAYS",
        "CUST_A_SHARE", "CUST_B_SHARE", "CUST_A_MARKUP", "CUST_B_MARKUP", 
        "CUST_A_DIFFICULTY", "CUST_B_DIFFICULTY",
        "PERFECTING_MAKEREADY_BONUS", "BASE_SPEED_WHITE_SHEETFED", "BASE_SPEED_WHITE_PERFECTING", 
        "BASE_SPEED_FOIL_SHEETFED", "BASE_SPEED_FOIL_PERFECTING",
        "DELTA_E_REJECT", "REGISTER_REJECT", "DOT_GAIN_REJECT", "CUT_DEVIATION_REJECT", "FOIL_ADHESION_FAIL",
        "MAKEREADY_NOISE_STD", "SPEED_NOISE_STD", "LEAD_TIME_MEAN_DAYS", "LEAD_TIME_STD_DAYS",
        "ACTUAL_TIME_MEAN", "ACTUAL_TIME_STD", "RANDOM_SEED", "START_DATE",
        "INK_COVERAGE_MIN", "INK_COVERAGE_MAX"
    ]

    xl_conf = {}
    for _, row in df_all.iterrows():
        param_name = str(row[0]).strip()
        if param_name in target_variables:
            try: xl_conf[param_name] = float(row[1])
            except: xl_conf[param_name] = row[1]
except Exception as e:
    print(f"❌ Error reading 'simulation_inputs.xlsx': {e}")
    sys.exit(1)

# ── 2. Excel-Driven Config ───────────────────────────────────────────────────
NUM_JOBS             = int(xl_conf.get("NUM_JOBS", 1000))
DATE_RANGE_DAYS      = int(xl_conf.get("DATE_RANGE_DAYS", 730))
SCENARIO_LABEL       = str(xl_conf.get("SCENARIO_NAME", "Base_Case")).replace(" ", "_")

# Scrap Logic
MKRDY_ATTEMPTS       = xl_conf.get("MAKEREADY_ATTEMPTS", 5)
MKRDY_SHEETS_PER     = xl_conf.get("SHEETS_PER_ATTEMPT", 50)
DEFECT_WINDOW        = xl_conf.get("DEFECT_WINDOW_SHEETS", 200)

# Multipliers
NIGHT_WASTE_FACTOR   = xl_conf.get("NIGHT_WASTE_FACTOR", 1.15)
NIGHT_QUALITY_FACTOR = xl_conf.get("NIGHT_QUALITY_FACTOR", 1.15)
FOIL_WASTE_FACTOR    = xl_conf.get("FOIL_WASTE_FACTOR", 1.25)
FOIL_MAKEREADY_FACTOR= xl_conf.get("FOIL_MAKEREADY_FACTOR", 1.25)
FOIL_SPEED_PENALTY   = xl_conf.get("FOIL_SPEED_PENALTY", 0.70)
SHEETFED_RATE_HR     = xl_conf.get("SHEETFED_RATE_HR", 295)
PERFECTING_RATE_HR   = xl_conf.get("PERFECTING_RATE_HR", 340)

# Press/Shift Mix
SHIFTS = {
    "Red Day": xl_conf.get("SHIFT_MIX_RED_DAY", 0.25), "Red Night": xl_conf.get("SHIFT_MIX_RED_NIGHT", 0.25),
    "Black Day": xl_conf.get("SHIFT_MIX_BLACK_DAY", 0.25), "Black Night": xl_conf.get("SHIFT_MIX_BLACK_NIGHT", 0.25),
}
LAYOUT_MIX = {
    (121, "White"): xl_conf.get("MIX_121_PLAIN", 0.40), (121, "Foil"): xl_conf.get("MIX_121_HOLO", 0.25),
    (100, "White"): xl_conf.get("MIX_100_PLAIN", 0.15), (100, "Foil"): xl_conf.get("MIX_100_HOLO", 0.20),
}
PRESSES = {
    "SF-1": ("Sheetfed", xl_conf.get("SHARE_SF1", 0.166), 1.0),
    "SF-2": ("Sheetfed", xl_conf.get("SHARE_SF2", 0.166), 1.0),
    "SF-3": ("Sheetfed", xl_conf.get("SHARE_SF3", 0.166), xl_conf.get("AGE_FACTOR_SF3", 1.2)),
    "SF-4": ("Sheetfed", xl_conf.get("SHARE_SF4", 0.166), 1.0),
    "PF-1": ("Perfecting", xl_conf.get("SHARE_PF1", 0.166), 1.0),
    "PF-2": ("Perfecting", xl_conf.get("SHARE_PF2", 0.170), xl_conf.get("AGE_FACTOR_PF2", 1.2)),
}

# Exposed Physics
PERFECTING_MAKEREADY_BONUS   = xl_conf.get("PERFECTING_MAKEREADY_BONUS", 0.80)
BASE_SPEED_WHITE_SHEETFED    = xl_conf.get("BASE_SPEED_WHITE_SHEETFED", 10500)
BASE_SPEED_WHITE_PERFECTING  = xl_conf.get("BASE_SPEED_WHITE_PERFECTING", 9500)
BASE_SPEED_FOIL_SHEETFED     = xl_conf.get("BASE_SPEED_FOIL_SHEETFED", 7500)
BASE_SPEED_FOIL_PERFECTING   = xl_conf.get("BASE_SPEED_FOIL_PERFECTING", 6500)
DELTA_E_REJECT       = xl_conf.get("DELTA_E_REJECT", 3.5)
REGISTER_REJECT      = xl_conf.get("REGISTER_REJECT", 2.0)
DOT_GAIN_REJECT      = xl_conf.get("DOT_GAIN_REJECT", 30.0)
CUT_DEVIATION_REJECT = xl_conf.get("CUT_DEVIATION_REJECT", 0.5)
FOIL_ADHESION_FAIL   = xl_conf.get("FOIL_ADHESION_FAIL", 70)
RANDOM_SEED          = int(xl_conf.get("RANDOM_SEED", 42))
START_DATE           = str(xl_conf.get("START_DATE", "2022-01-01")).split(" ")[0]

# ── 3. Hardcoded Matrices ────────────────────────────────────────────────────
STOCK_COST_PER_MSF = {"White": xl_conf.get("STOCK_COST_WHITE", 55), "Foil": xl_conf.get("STOCK_COST_FOIL", 320)}
INK_COST_PER_LB    = xl_conf.get("INK_COST_PER_LB", 20)
INK_COVERAGE_RANGE = (xl_conf.get("INK_COVERAGE_MIN", 0.55), xl_conf.get("INK_COVERAGE_MAX", 0.90))

INK_CONFIG_MIX = {"4/4 CMYK": 0.45, "4/4 + Spot Gloss": 0.25, "4/4 + Foil Stamp": 0.15, "4/4 + Spot UV": 0.15}
PLATE_COST = {"4/4 CMYK": 260, "4/4 + Spot Gloss": 380, "4/4 + Foil Stamp": 520, "4/4 + Spot UV": 380}
FINISHING_COST_PER_SHEET = {"4/4 CMYK": 0.000, "4/4 + Spot Gloss": 0.009, "4/4 + Foil Stamp": 0.018, "4/4 + Spot UV": 0.009}
MAKEREADY_BASE_MIN = {"4/4 CMYK": 75, "4/4 + Spot Gloss": 90, "4/4 + Foil Stamp": 120, "4/4 + Spot UV": 95}

# HIGH-VOLUME QTY MATRIX (Updated: 15k is the small run)
QTY_OPTIONS = {15000: 0.30, 25000: 0.30, 40000: 0.20, 60000: 0.10, 100000: 0.10}

WASTE_BASE = {
    ("White", "4/4 CMYK"): 0.025, ("White", "4/4 + Spot Gloss"): 0.038, ("White", "4/4 + Foil Stamp"): 0.045, ("White", "4/4 + Spot UV"): 0.038,
    ("Foil", "4/4 CMYK"): 0.055, ("Foil", "4/4 + Spot Gloss"): 0.060, ("Foil", "4/4 + Foil Stamp"): 0.065, ("Foil", "4/4 + Spot UV"): 0.060,
}
DELTA_E_BASE = {"White": 1.2, "Foil": 1.8}; REGISTER_BASE = {"White": 0.5, "Foil": 0.8}

# ── 4. Generation Logic ──────────────────────────────────────────────────────
def normalize(probs):
    arr = np.array(probs, dtype='float64')
    return arr / arr.sum()

def generate_dataset():
    np.random.seed(RANDOM_SEED); random.seed(RANDOM_SEED)
    n = NUM_JOBS
    dates = sorted([datetime.strptime(START_DATE, "%Y-%m-%d") + timedelta(days=random.randint(0, DATE_RANGE_DAYS)) for _ in range(n)])

    # CUSTOMER PROFILE LOGIC (95/5 split)
    customer_ids = ["CUST-A", "CUST-B"]
    cust_shares  = [xl_conf.get("CUST_A_SHARE", 0.95), xl_conf.get("CUST_B_SHARE", 0.05)]
    cust_markups = {"CUST-A": xl_conf.get("CUST_A_MARKUP", 1.25), "CUST-B": xl_conf.get("CUST_B_MARKUP", 1.40)}
    cust_diffs   = {"CUST-A": xl_conf.get("CUST_A_DIFFICULTY", 1.0), "CUST-B": xl_conf.get("CUST_B_DIFFICULTY", 1.0)}

    selected_custs      = np.random.choice(customer_ids, n, p=normalize(cust_shares))
    job_markups         = np.array([cust_markups[c] for c in selected_custs])
    job_diff_multiplier = np.array([cust_diffs[c] for c in selected_custs])

    # Distributions
    shifts = np.random.choice(list(SHIFTS.keys()), n, p=normalize(list(SHIFTS.values())))
    presses = np.random.choice(list(PRESSES.keys()), n, p=normalize([v[1] for v in PRESSES.values()]))
    ink_config = np.random.choice(list(INK_CONFIG_MIX.keys()), n, p=normalize(list(INK_CONFIG_MIX.values())))
    qty_sheets = np.random.choice(list(QTY_OPTIONS.keys()), n, p=normalize(list(QTY_OPTIONS.values())))
    
    selected_indices = np.random.choice(len(list(LAYOUT_MIX.keys())), n, p=normalize(list(LAYOUT_MIX.values())))
    cards_per_sheet = np.array([list(LAYOUT_MIX.keys())[i][0] for i in selected_indices])
    stock_type = np.array([list(LAYOUT_MIX.keys())[i][1] for i in selected_indices])

    press_type_arr = np.array([PRESSES[p][0] for p in presses]); press_age_arr = np.array([PRESSES[p][2] for p in presses])
    is_night = np.isin(shifts, ["Red Night", "Black Night"]); is_foil = stock_type == "Foil"; is_perfecting = press_type_arr == "Perfecting"
    night_factor = np.where(is_night, NIGHT_WASTE_FACTOR, 1.0); foil_factor = np.where(is_foil, FOIL_WASTE_FACTOR, 1.0)
    quality_factor = night_factor * press_age_arr * job_diff_multiplier

    # Physics
    delta_e = (np.random.exponential(np.array([DELTA_E_BASE[s] for s in stock_type]), n) * quality_factor).clip(0.1, 9.0)
    register_err = (np.random.exponential(np.array([REGISTER_BASE[s] for s in stock_type]), n) * quality_factor).clip(0.0, 5.0)
    dot_gain = np.random.normal(21, 3, n).clip(10, 38)
    foil_adhesion = np.where(is_foil, np.random.normal(88, 8, n).clip(40, 100), np.nan)
    cut_dev = (np.random.exponential(0.12, n) * foil_factor * quality_factor).clip(0.0, 1.5)

    quality_pass = ((delta_e < DELTA_E_REJECT) & (register_err < REGISTER_REJECT) & (dot_gain < DOT_GAIN_REJECT) & (cut_dev < CUT_DEVIATION_REJECT)).astype(int)
    quality_pass = np.where((stock_type == "Foil") & (foil_adhesion < FOIL_ADHESION_FAIL), 0, quality_pass)

    # 3-Phase Waste (Surgically Protected)
    mkrdy_scrap = np.full(n, MKRDY_ATTEMPTS * MKRDY_SHEETS_PER)
    running_waste_pct = np.array([WASTE_BASE.get((s, c), 0.04) for s, c in zip(stock_type, ink_config)]) * foil_factor * night_factor * press_age_arr * job_diff_multiplier
    running_scrap = (qty_sheets * running_waste_pct).astype(int)
    qc_failed_scrap = np.where(quality_pass == 0, DEFECT_WINDOW, 0)
    
    total_waste_sheets = mkrdy_scrap + running_scrap + qc_failed_scrap
    sheets_run = qty_sheets + total_waste_sheets
    qty_cards = qty_sheets * cards_per_sheet

    # Financials
    mkrdy_base = np.array([MAKEREADY_BASE_MIN[c] for c in ink_config])
    makeready_time = (mkrdy_base * np.where(is_foil, FOIL_MAKEREADY_FACTOR, 1.0) * press_age_arr * np.where(is_perfecting, PERFECTING_MAKEREADY_BONUS, 1.0) + np.random.normal(0, 12, n)).astype(int)
    speed_base = np.where(is_foil & is_perfecting, BASE_SPEED_FOIL_PERFECTING, np.where(is_foil, BASE_SPEED_FOIL_SHEETFED, np.where(is_perfecting, BASE_SPEED_WHITE_PERFECTING, BASE_SPEED_WHITE_SHEETFED)))
    press_speed = (speed_base / press_age_arr + np.random.normal(0, 400, n)).astype(int)
    passes = np.where(is_perfecting, 1, 2)
    total_time = ((makeready_time / 60) + (sheets_run * passes / press_speed)).round(2)

    paper_cost = (sheets_run / 1000 * np.array([STOCK_COST_PER_MSF[s] for s in stock_type])).round(2)
    press_cost = (total_time * np.where(is_perfecting, PERFECTING_RATE_HR, SHEETFED_RATE_HR)).round(2)
    ink_lbs = (sheets_run * np.random.uniform(*INK_COVERAGE_RANGE, n) * 4 * 2 / 50000)
    ink_cost = (ink_lbs * INK_COST_PER_LB).round(2)
    plate_cost = np.array([PLATE_COST[c] for c in ink_config], dtype=float)
    finishing_cost = (sheets_run * np.array([FINISHING_COST_PER_SHEET[c] for c in ink_config])).round(2)
    total_cost = (paper_cost + press_cost + ink_cost + plate_cost + finishing_cost).round(2)
    
    # DETERMINISTIC CUSTOMER REVENUE
    revenue = (total_cost * job_markups).round(2)

    return pd.DataFrame({
        "job_id": [f"JOB-{str(i).zfill(5)}" for i in range(1, n+1)], "job_date": [d.strftime("%Y-%m-%d") for d in dates],
        "customer_id": selected_custs, "shift": shifts, "press": presses, "press_type": press_type_arr,
        "stock_type": stock_type, "ink_config": ink_config, "qty_sheets_ordered": qty_sheets,
        "sheets_run": sheets_run, "waste_sheets": total_waste_sheets, 
        "waste_pct": (total_waste_sheets / sheets_run * 100).round(2),
        "total_press_time_hrs": total_time, "quality_pass": quality_pass, "rerun_required": np.where(quality_pass == 0, 1, 0),
        "total_cost": total_cost, "revenue": revenue, "gross_profit": (revenue - total_cost).round(2),
        "gross_margin_pct": ((revenue - total_cost) / revenue * 100).round(1), "cost_per_card": (total_cost / qty_cards).round(4)
    })

if __name__ == "__main__":
    df = generate_dataset()
    OUTPUT_XLSX = os.path.join(script_dir, f"results_{SCENARIO_LABEL}.xlsx")
    df.to_excel(OUTPUT_XLSX, index=False)
    print(f"✅ Success! Data generated and saved to: {OUTPUT_XLSX}")
    import subprocess
    subprocess.call(["open", OUTPUT_XLSX])