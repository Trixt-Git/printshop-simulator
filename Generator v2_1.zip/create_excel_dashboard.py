"""
Trading Card Print Shop — Scenario-Aware Excel Generator (V6 - Absolute Full Restore)
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import os

def create_control_panel():
    wb = openpyxl.Workbook()
    ws_front = wb.active
    ws_front.title = "Main Control Panel"
    ws_back = wb.create_sheet("Backend Engine")

    header_font = Font(bold=True, color="FFFFFF", size=12)
    header_fill = PatternFill("solid", start_color="1F4E79")
    sub_fill = PatternFill("solid", start_color="BDD7EE")
    left_align = Alignment(horizontal="left", vertical="center")
    center_align = Alignment(horizontal="center", vertical="center")

    def setup_sheet(ws, title_text):
        ws.column_dimensions['A'].width = 35
        ws.column_dimensions['B'].width = 40
        ws.column_dimensions['C'].width = 90
        ws.cell(row=1, column=1, value=title_text).font = Font(bold=True, size=16)
        ws.freeze_panes = "A2"

    def add_section(ws, current_row, title):
        current_row += 1
        for col in range(1, 4): ws.cell(row=current_row, column=col).fill = header_fill
        ws.cell(row=current_row, column=1, value=title).font = header_font
        current_row += 1
        ws.cell(row=current_row, column=1, value="Parameter").fill = sub_fill
        ws.cell(row=current_row, column=2, value="Value").fill = sub_fill
        ws.cell(row=current_row, column=3, value="Description").fill = sub_fill
        return current_row + 1

    def add_variable(ws, current_row, name, value, description):
        ws.cell(row=current_row, column=1, value=name).alignment = left_align
        ws.cell(row=current_row, column=2, value=value).alignment = center_align
        ws.cell(row=current_row, column=3, value=description).alignment = left_align
        return current_row + 1

    # --- FRONT SHEET ---
    setup_sheet(ws_front, "Executive Dashboard - Strategic Levers")
    row = 1
    
    row = add_section(ws_front, row, "0. Scenario Metadata")
    row = add_variable(ws_front, row, "SCENARIO_NAME", "Full_Engine_Restored", "Label for output filenames. Avoid spaces.")

    row = add_section(ws_front, row, "1. Fixed Scrap & QC Windows")
    row = add_variable(ws_front, row, "MAKEREADY_ATTEMPTS", 5, "Average attempts to get color/register right before production")
    row = add_variable(ws_front, row, "SHEETS_PER_ATTEMPT", 50, "Sheets pulled per makeready setup attempt")
    row = add_variable(ws_front, row, "DEFECT_WINDOW_SHEETS", 200, "Number of sheets scrapped if QC fails mid/late run")
    row = add_variable(ws_front, row, "QC_FAILURE_PROB", 0.15, "Probability that a defect window occurs during production")

    row = add_section(ws_front, row, "2. Operational Layout Mix (Must sum to 1.0)")
    row = add_variable(ws_front, row, "MIX_121_PLAIN", 0.40, "Percentage of jobs running 121-up on Plainstock")
    row = add_variable(ws_front, row, "MIX_121_HOLO", 0.25, "Percentage of jobs running 121-up on Holofoil")
    row = add_variable(ws_front, row, "MIX_100_PLAIN", 0.15, "Percentage of jobs running 100-up on Plainstock")
    row = add_variable(ws_front, row, "MIX_100_HOLO", 0.20, "Percentage of jobs running 100-up on Holofoil")

    row = add_section(ws_front, row, "3. Shift Routing (Must sum to 1.0)")
    row = add_variable(ws_front, row, "SHIFT_MIX_RED_DAY", 0.25, "Percentage of jobs assigned to Red Day shift")
    row = add_variable(ws_front, row, "SHIFT_MIX_RED_NIGHT", 0.25, "Percentage of jobs assigned to Red Night shift")
    row = add_variable(ws_front, row, "SHIFT_MIX_BLACK_DAY", 0.25, "Percentage of jobs assigned to Black Day shift")
    row = add_variable(ws_front, row, "SHIFT_MIX_BLACK_NIGHT", 0.25, "Percentage of jobs assigned to Black Night shift")

    row = add_section(ws_front, row, "4. Shift & Material Penalties")
    row = add_variable(ws_front, row, "NIGHT_WASTE_FACTOR", 1.15, "Multiplier on waste % for night shifts (1.0 = no penalty)")
    row = add_variable(ws_front, row, "NIGHT_QUALITY_FACTOR", 1.15, "Multiplier on quality errors for night shifts")
    row = add_variable(ws_front, row, "FOIL_WASTE_FACTOR", 1.25, "Waste multiplier when running Foil stock")
    row = add_variable(ws_front, row, "FOIL_MAKEREADY_FACTOR", 1.25, "Makeready time multiplier when running Foil stock")
    row = add_variable(ws_front, row, "FOIL_SPEED_PENALTY", 0.70, "Press speed multiplier for Foil (0.70 = runs at 70% speed)")

    # --- BACKEND ENGINE ---
    setup_sheet(ws_back, "Backend Engine - Manufacturing Constants")
    row = 1
    
    row = add_section(ws_back, row, "1. Press Fleet Job Shares (Must sum to 1.0)")
    row = add_variable(ws_back, row, "SHARE_SF1", 0.166, "Job share routed to SF-1 (Sheetfed)")
    row = add_variable(ws_back, row, "SHARE_SF2", 0.166, "Job share routed to SF-2 (Sheetfed)")
    row = add_variable(ws_back, row, "SHARE_SF3", 0.166, "Job share routed to SF-3 (Sheetfed - Older)")
    row = add_variable(ws_back, row, "SHARE_SF4", 0.166, "Job share routed to SF-4 (Sheetfed)")
    row = add_variable(ws_back, row, "SHARE_PF1", 0.166, "Job share routed to PF-1 (Perfecting)")
    row = add_variable(ws_back, row, "SHARE_PF2", 0.170, "Job share routed to PF-2 (Perfecting - Older)")

    row = add_section(ws_back, row, "2. Equipment Age Penalties")
    row = add_variable(ws_back, row, "AGE_FACTOR_SF3", 1.2, "Performance penalty for older SF-3 (>1.0 = slower and more waste)")
    row = add_variable(ws_back, row, "AGE_FACTOR_PF2", 1.2, "Performance penalty for older PF-2 (>1.0 = slower and more waste)")

    row = add_section(ws_back, row, "3. Financials & Costs")
    row = add_variable(ws_back, row, "SHEETFED_RATE_HR", 295, "Hourly operating cost for Sheetfed presses ($)")
    row = add_variable(ws_back, row, "PERFECTING_RATE_HR", 340, "Hourly operating cost for Perfecting presses ($)")
    row = add_variable(ws_back, row, "STOCK_COST_WHITE", 55, "Cost per thousand sheets (MSF) for White ($)")
    row = add_variable(ws_back, row, "STOCK_COST_FOIL", 320, "Cost per thousand sheets (MSF) for Foil ($)")
    row = add_variable(ws_back, row, "INK_COST_PER_LB", 20, "Cost of ink per pound ($)")
    row = add_variable(ws_back, row, "MARKUP_MIN", 1.18, "Minimum revenue markup applied over total cost")
    row = add_variable(ws_back, row, "MARKUP_MAX", 1.65, "Maximum revenue markup applied over total cost")
    
    row = add_section(ws_back, row, "4. General Volume")
    row = add_section(ws_back, row, "4. General Volume & Customer Mix")
    row = add_variable(ws_back, row, "NUM_JOBS", 1000, "Total number of print jobs to simulate")
    row = add_variable(ws_back, row, "DATE_RANGE_DAYS", 730, "Spread generated jobs over this many days")
    row = add_variable(ws_back, row, "CUST_A_SHARE", 0.95, "Percentage of total orders belonging to Customer A")
    row = add_variable(ws_back, row, "CUST_B_SHARE", 0.05, "Percentage of total orders belonging to Customer B")

    row = add_section(ws_back, row, "5. Customer Profitability & Difficulty (Constants)")
    row = add_variable(ws_back, row, "CUST_A_MARKUP", 1.25, "Flat markup for Customer A (1.25 = 25% profit)")
    row = add_variable(ws_back, row, "CUST_B_MARKUP", 1.40, "Flat markup for Customer B (1.40 = 40% profit)")
    row = add_variable(ws_back, row, "CUST_A_DIFFICULTY", 1.0, "Waste multiplier for Customer A (1.0 = standard)")
    row = add_variable(ws_back, row, "CUST_B_DIFFICULTY", 1.0, "Waste multiplier for Customer B (1.0 = standard)")
    row = add_section(ws_back, row, "5. Complex Matrices (Hardcoded)")
    row = add_section(ws_back, row, "5. Base Speeds & Output Math")
    row = add_variable(ws_back, row, "PERFECTING_MAKEREADY_BONUS", 0.80, "Time reduction multiplier for perfecting presses (0.80 = 20% faster)")
    row = add_variable(ws_back, row, "BASE_SPEED_WHITE_SHEETFED", 10500, "Baseline Sheets Per Hour (SPH) for White stock on Sheetfed")
    row = add_variable(ws_back, row, "BASE_SPEED_WHITE_PERFECTING", 9500, "Baseline SPH for White stock on Perfecting presses")
    row = add_variable(ws_back, row, "BASE_SPEED_FOIL_SHEETFED", 7500, "Baseline SPH for Foil stock on Sheetfed")
    row = add_variable(ws_back, row, "BASE_SPEED_FOIL_PERFECTING", 6500, "Baseline SPH for Foil stock on Perfecting presses")

    row = add_section(ws_back, row, "6. Hard QC Failure Thresholds (Defect Triggers)")
    row = add_variable(ws_back, row, "DELTA_E_REJECT", 3.5, "Maximum allowable color variance. Above this triggers a defect window.")
    row = add_variable(ws_back, row, "REGISTER_REJECT", 2.0, "Maximum allowable misregistration (thousandths).")
    row = add_variable(ws_back, row, "DOT_GAIN_REJECT", 30.0, "Maximum allowable dot gain percentage.")
    row = add_variable(ws_back, row, "CUT_DEVIATION_REJECT", 0.5, "Maximum allowable cut deviation (mm).")
    row = add_variable(ws_back, row, "FOIL_ADHESION_FAIL", 70, "Minimum required foil adhesion score (out of 100).")

    row = add_section(ws_back, row, "7. Gaussian Noise & Delivery Constants")
    row = add_variable(ws_back, row, "MAKEREADY_NOISE_STD", 12, "Standard deviation (minutes) of random noise applied to makeready times.")
    row = add_variable(ws_back, row, "SPEED_NOISE_STD", 400, "Standard deviation (SPH) of random noise applied to running speeds.")
    row = add_variable(ws_back, row, "LEAD_TIME_MEAN_DAYS", 8, "Average days quoted to customer for job completion.")
    row = add_variable(ws_back, row, "LEAD_TIME_STD_DAYS", 2, "Standard deviation of quoted lead time.")
    row = add_variable(ws_back, row, "ACTUAL_TIME_MEAN", 8, "Average actual days taken to complete a job.")
    row = add_variable(ws_back, row, "ACTUAL_TIME_STD", 2, "Standard deviation of actual completion time.")

    row = add_section(ws_back, row, "8. General Simulation Seeds")
    row = add_variable(ws_back, row, "RANDOM_SEED", 42, "Seed for random number generator (ensures reproducible scenarios).")
    row = add_variable(ws_back, row, "START_DATE", "2022-01-01", "Start date for generating print jobs (YYYY-MM-DD).")
    row = add_variable(ws_back, row, "NUM_CUSTOMERS", 3, "Number of unique customer IDs to generate in the pool.")
    row = add_variable(ws_back, row, "INK_COVERAGE_MIN", 0.55, "Minimum ink coverage percentage per sheet (0.55 = 55%).")
    row = add_variable(ws_back, row, "INK_COVERAGE_MAX", 0.90, "Maximum ink coverage percentage per sheet (0.90 = 90%).")

    row = add_section(ws_back, row, "9. Complex Matrices (Hardcoded)")
    pointer = "Must be changed in code, check line x"
    row = add_variable(ws_back, row, "INK_CONFIG_MIX", pointer, "Probability distribution of ink and finishing configurations. Must sum to 1.0.")
    row = add_variable(ws_back, row, "PLATE_COST", pointer, "The flat setup cost ($) for creating the physical printing plates.")
    row = add_variable(ws_back, row, "FINISHING_COST_PER_SHEET", pointer, "The variable, per-sheet cost ($) added for post-press finishing.")
    row = add_variable(ws_back, row, "QTY_OPTIONS", pointer, "The probability distribution defining the frequency of customer order sizes.")
    row = add_variable(ws_back, row, "MAKEREADY_BASE_MIN", pointer, "The baseline setup time (in minutes) required to prepare the press.")
    row = add_variable(ws_back, row, "WASTE_BASE", pointer, "A matrix defining the baseline expected waste percentage based on stock and ink.")
    row = add_variable(ws_back, row, "DELTA_E_BASE", pointer, "The statistical baseline used to simulate color accuracy errors.")
    row = add_variable(ws_back, row, "REGISTER_BASE", pointer, "The statistical baseline used to simulate mechanical misregistration errors.")

    filename = "simulation_inputs.xlsx"
    # --- END OF create_control_panel function ---
    # Force the path to be relative to THIS script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    filename = os.path.join(script_dir, "simulation_inputs.xlsx")
    
    wb.save(filename)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    filename = os.path.join(script_dir, "simulation_inputs.xlsx")
    
    wb.save(filename)
    # Ensure we return the filename so the Generator knows where it went
    return filename

if __name__ == "__main__":
    path = create_control_panel()
    print(f"✅ Success! Dashboard created at: {path}")