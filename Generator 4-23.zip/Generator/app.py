import streamlit as st
import plotly.express as px
import pandas as pd
from trading_card_generate_dataset import generate_dataset

# ── PAGE CONFIG ──────────────────────────────────────────────────────────
# This must be the first Streamlit call in the file.
st.set_page_config(
    page_title="Print Shop Simulator",
    layout="wide"
)

st.title("Trading Card Print Shop — Live Simulator")
st.caption("Move any slider to rerun the simulation and see the system respond.")

# ── SIDEBAR CONTROLS ─────────────────────────────────────────────────────
# st.sidebar puts widgets in the left panel.
# Each slider returns its current value as a Python variable.
st.sidebar.header("Simulation Controls")

st.sidebar.subheader("Press Fleet")
age_sf3 = st.sidebar.slider("SF-3 Age Factor", 1.0, 2.0, 1.2, step=0.05,
                            help="1.0=New | 1.2=Mid-life | 1.4=Aging | 1.6=Degraded | 1.8=End of Life | 2.0=Critical")
age_pf2 = st.sidebar.slider("PF-2 Age Factor", 1.0, 2.0, 1.2, step=0.05,
                            help="1.0=New | 1.2=Mid-life | 1.4=Aging | 1.6=Degraded | 1.8=End of Life | 2.0=Critical")

st.sidebar.subheader("Night Shift")
night_waste = st.sidebar.slider("Night Waste Factor", 1.0, 1.5, 1.15, step=0.05)
night_quality = st.sidebar.slider("Night Quality Factor", 1.0, 1.5, 1.15, step=0.05)

st.sidebar.subheader("Stock & Material")
foil_waste = st.sidebar.slider("Foil Waste Factor", 1.0, 2.0, 1.25, step=0.05)
jam_rate = st.sidebar.slider("Jam Rate (per 10K sheets)", 0.0, 0.15, 0.03, step=0.01)

st.sidebar.subheader("Volume")
num_jobs = st.sidebar.slider("Number of Jobs", 500, 5000, 1000, step=500)

# ── RUN SIMULATION ───────────────────────────────────────────────────────
# Build the overrides dict from slider values,
# then call the generator. This reruns every time a slider moves.

# st.cache_data tells Streamlit: if you've seen this exact set of inputs
# before, return the cached result instead of rerunning. Makes sliders feel
# snappy. The overrides must be a tuple (not a dict) because dicts can't
# be hashed for caching.

@st.cache_data
def run_sim(overrides_tuple):
    return generate_dataset(dict(overrides_tuple))

overrides = {
    "AGE_FACTOR_SF3":          age_sf3,
    "AGE_FACTOR_PF2":          age_pf2,
    "NIGHT_WASTE_FACTOR":      night_waste,
    "NIGHT_QUALITY_FACTOR":    night_quality,
    "FOIL_WASTE_FACTOR":       foil_waste,
    "JAM_RATE_PER_10K_SHEETS": jam_rate,
    "NUM_JOBS":                num_jobs,
}

with st.spinner("Running simulation..."):
    df = run_sim(tuple(sorted(overrides.items())))

# ── KPI STRIP ────────────────────────────────────────────────────────────
# st.columns splits the row into equal-width panels.
# st.metric shows a big number with a label — clean and readable.

st.subheader("Top Line")
k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Total Profit",  f"${df['gross_profit'].sum():,.0f}")
k2.metric("Avg Margin",    f"{df['gross_margin_pct'].mean():.1f}%")
k3.metric("Late Rate",     f"{(df['delivery_status']=='LATE').mean():.1%}")
k4.metric("Avg Waste",     f"{df['waste_pct'].mean():.1f}%")
k5.metric("QC Fail Rate",  f"{(df['quality_pass']==0).mean():.1%}")

st.divider()

# ── CHARTS ───────────────────────────────────────────────────────────────
# Row 1: two charts side by side
col1, col2 = st.columns(2)
with col1:
    st.subheader("Margin Distribution")
    st.caption("Shape tells you stability. Wide spread = unpredictable jobs.")
    fig = px.histogram(df, x="gross_margin_pct", nbins=50,
                       color="Customer",
                       barmode="overlay",
                       opacity=0.7)
    fig.update_layout(showlegend=False, xaxis_title="Gross Margin %", yaxis_title="Jobs")
    st.plotly_chart(fig, width ='stretch')
    color_by = st.selectbox("Color by",["Customer", "Stock Type", "Press", "Shift"], key="hist_color")
    fig2 = px.histogram(df, x="gross_margin_pct", nbins=50,
                        color=color_by,
                        barmode="overlay",
                        opacity=0.7)
    st.plotly_chart(fig2, use_container_width=True)

with col2:
    st.subheader("Margin by Press")
    st.caption("SF-3 and PF-2 should show lower medians and wider boxes.")
    fig = px.box(df, x="Press", y="gross_margin_pct",
                 color="Press", color_discrete_sequence=px.colors.qualitative.Set2)
    fig.update_layout(showlegend=False, xaxis_title="Press", yaxis_title="Gross Margin %")
    st.plotly_chart(fig, width ='stretch')

# Row 2: two more charts
col3, col4 = st.columns(2)

with col3:
    st.subheader("Waste % vs Gross Profit")
    st.caption("Higher waste should mean lower profit. Color by press reveals outliers.")
    fig = px.scatter(df, x="waste_pct", y="gross_profit", color="Press",
                     opacity=0.5, color_discrete_sequence=px.colors.qualitative.Set2)
    fig.update_layout(xaxis_title="Waste %", yaxis_title="Gross Profit ($)")
    st.plotly_chart(fig, width ='stretch')

with col4:
    st.subheader("Quality Pass Rate by Shift")
    st.caption("Night shifts should show lower pass rates. Day vs night gap = model signal.")
    shift_qc = df.groupby("Shift")["quality_pass"].mean().reset_index()
    shift_qc.columns = ["Shift", "pass_rate"]
    shift_qc["pass_rate_pct"] = shift_qc["pass_rate"] * 100
    fig = px.bar(shift_qc, x="Shift", y="pass_rate_pct",
                 color="Shift", color_discrete_sequence=px.colors.qualitative.Set2)
    fig.update_layout(showlegend=False, yaxis_range=[0, 100],
                      xaxis_title="Shift", yaxis_title="Pass Rate %")
    st.plotly_chart(fig, width ='stretch')
    
    # ---Dataframe checks - Uncomment Line to run------------------------- 
    #
    # ---QC stats: avg, mean, std dev, etc.
    # st.dataframe(df[['color_delta_e', 'register_error', 'dot_gain_pct', 'cut_deviation_mm']].describe().round(3))
    # ---QC count----
    # st.write("QC failure breakdown")
    # st.dataframe(pd.DataFrame({
    #     "delta_e_fails":     (df["color_delta_e"] > 3.5).mean(),
    #     "register_fails":    (df["register_error"] > 2.0).mean(),
    #     "dot_gain_fails":    (df["dot_gain_pct"] > 30.0).mean(),
    #     "cut_dev_fails":     (df["cut_deviation_mm"] > 0.5).mean(),
    #     "foil_adhesion_fails": (df["foil_adhesion"] < 70).mean(),
    # }, index=["fail_rate"]).T.round(3))
    # ---Shift Variance on quality ----
    # st.dataframe(df.groupby(["Press","Shift"])["quality_pass"].mean().unstack().round(3))
    #---Age Factor------
    st.dataframe(df.groupby("Press")[["quality_pass","waste_pct","gross_margin_pct"]].mean().round(2))


# ── RAW DATA (optional, collapsible) ─────────────────────────────────────
with st.expander("Show raw data sample"):
    st.dataframe(df.head(50))
